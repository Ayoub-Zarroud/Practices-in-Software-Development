import pgzrun   

sun = Actor('sun')  
sun.x = 400     
sun.y = 300    

earth = Actor('earth', anchor=(310, 65))  
earth.x = 400     
earth.y = 300     

needle = Actor('needle' , anchor = (180,0))
needle.x = 400
needle.y = 300

def draw():    
    screen.fill('black')   
    sun.draw()     
    earth.draw()   
    needle.draw()

def update():    
    earth.angle = earth.angle + 1   
    needle.angle = needle.angle + 1

pgzrun.go()    
