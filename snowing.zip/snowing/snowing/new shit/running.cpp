#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"
#include <vector> // Include vector for dynamic array management
#include <cstdlib> // For rand()
#include <ctime> // For seeding rand()
#include <mmsystem.h> // For PlaySound function

#pragma comment(lib, "winmm.lib") // Link against the winmm.lib for multimedia functions

#define WIDTH  787
#define HEIGHT 590

struct Snowball {
    int x; // Horizontal position
    int y; // Vertical position
    int speedY; // Speed of falling vertically
    int speedX; // Speed of horizontal movement
    int direction; // Direction of horizontal movement; 1 for right, -1 for left

    Snowball(int startX) {
        x = startX;
        y = 0; // Start at the top
        speedY = 5 + rand() % 3; // Random vertical speed between 5 and 7
        speedX = 2; // Fixed horizontal speed
        direction = (rand() % 2 == 0) ? 1 : -1; // Random initial direction
    }

    void update() {
        // Update vertical position to make it fall straight down
        if (rand() % 2 == 0)
            x += 3;
        else
            x -= 3;

        y += 3;

        if (y > 590)
        {
            x = rand() % 787;
            y = rand() % 787;
            y = 0;
        }

    }
};

    // Function to play music
    void playMusic() {
        mciSendString(TEXT("open \"game_music.mp3\" type mpegvideo alias bgm"), NULL, 0, NULL);
        mciSendString(TEXT("play bgm repeat"), NULL, 0, NULL);
    }

    // Function to stop music
    void stopMusic() {
        mciSendString(TEXT("stop bgm"), NULL, 0, NULL);
        mciSendString(TEXT("close bgm"), NULL, 0, NULL);
    }

    int main()
    {
        IMAGE im_bk, im_snowball;
        initgraph(WIDTH, HEIGHT);

        // Load background image
        loadimage(&im_bk, _T("bg.png"));
        // Load snowball image
        loadimage(&im_snowball, _T("snow.png"));

        // Seed random number generator
        srand(static_cast<unsigned>(time(0)));

        // Create a vector to hold multiple snowballs
        std::vector<Snowball> snowballs;

        // Start time for adding snowballs
        int lastTime = GetTickCount(); // Get current time in milliseconds
        int interval = 3000; // 3 seconds interval

        BeginBatchDraw();
        while (true)
        {
            // Clear the screen and draw the background
            putimage(0, 0, &im_bk); // Draw the background (stationary)

            // Update and draw each snowball
            for (auto& snowball : snowballs) {
                snowball.update(); // Update position
                putimagePng(snowball.x, snowball.y, &im_snowball); // Draw snowball
            }

            // Check if it's time to add new snowballs
            int currentTime = GetTickCount();
            if (currentTime - lastTime >= interval) {
                // Add 1 new snowball every 3 seconds
                int startX = rand() % (WIDTH - 100); // Random horizontal starting position
                snowballs.emplace_back(startX); // Add new snowball
                lastTime = currentTime; // Update last time
            }

            // Sleep for a short duration to control the falling speed
            Sleep(60);

            FlushBatchDraw();
            playMusic();
        }

        _getch();
        return 0;
    }