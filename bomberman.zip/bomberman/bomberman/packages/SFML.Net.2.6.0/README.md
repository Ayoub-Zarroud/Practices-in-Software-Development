# SFML.Net NuGet Metapackage
This folder is used to build the SFML.Net Metapackage, which has no content by itself,
but contains all SFML Modules as dependencies, allowing consumers to target a single 
NuGet Package (`SFML.Net`) when building new applications.
