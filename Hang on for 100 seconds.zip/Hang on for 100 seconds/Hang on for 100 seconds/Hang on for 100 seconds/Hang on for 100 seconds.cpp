#pragma comment(lib, "winmm.lib")
#pragma warning(default: 4996)

#include <Windows.h>
#include <mmsystem.h>
#include <graphics.h>  
#include <conio.h>
#include <time.h>
#include "EasyXPng.h" // display PNG type of images
#include <chrono>  
#define  WIDTH  560              
#define  HEIGHT 800             
#define	 MaxBulletNum 200        // total number of bullets
#define  UFO_SPEED 2 

class Bullet
{
public:
    IMAGE im_bullet;
    float x, y;
    float vx, vy;
    float radius;

    void draw()
    {
        putimagePng(x - radius, y - radius, &im_bullet);

    }

    void update()
    {
        x += vx;
        y += vy;
        if (x <= 0 || x >= WIDTH)
            vx = -vx;
        if (y <= 0 || y >= HEIGHT)
            vy = -vy;
    }
};

class Rocket {
public:
    IMAGE im_rocket;
    float x, y;
    float width, height;

    void draw() {
        putimagePng(x - width / 2, y - height / 2, &im_rocket);
    }

    void update(float mx, float my) {
        x = mx;
        y = my;
    }
};

class Ufo {
public:
    IMAGE im_ufo;
    float x, y;
    float width, height;

    void draw() {
        putimagePng(x - width / 2, y - height / 2, &im_ufo);
    }



    void update(float rocketX, float rocketY) {
        // Calculate direction to the rocket
        float dx = rocketX - x;
        float dy = rocketY - y;
        float distance = sqrt(dx * dx + dy * dy);

        // Normalize direction and move the UFO towards the rocket
        if (distance > 0) {
            x += (dx / distance) * UFO_SPEED;
            y += (dy / distance) * UFO_SPEED;
        }
    }
};

IMAGE im_bk, im_bullet, im_rocket, im_heart, im_ufo, im_blowup;
Bullet bullet[MaxBulletNum];
Rocket rocket;
Ufo ufo;

int bulletNum = 0;
int heartCount = 4;

// Timer variables
auto startTime = std::chrono::high_resolution_clock::now(); // Start timer

// Function to check if two objects are colliding
bool checkCollision(float x1, float y1, float width1, float height1,
    float x2, float y2, float width2, float height2) {
    // Adding a buffer of 10 pixels for the UFO collision detection
    float buffer = 10.0f;

    return (x1 < x2 + width2 + buffer &&
        x1 + width1 > x2 - buffer &&
        y1 < y2 + height2 + buffer &&
        y1 + height1 > y2 - buffer);
}


// Function to play music
void playMusic() {
    mciSendString(TEXT("open \"game_music.mp3\" type mpegvideo alias bgm"), NULL, 0, NULL);
    mciSendString(TEXT("play bgm repeat"), NULL, 0, NULL);
}

// Function to stop music
void stopMusic() {
    mciSendString(TEXT("stop bgm"), NULL, 0, NULL);
    mciSendString(TEXT("close bgm"), NULL, 0, NULL);
}

// Function to handle collision between the UFO and the rocket
void handleCollision() {
    if (checkCollision(rocket.x, rocket.y, rocket.width, rocket.height, ufo.x, ufo.y, ufo.width, ufo.height)) {
        float explosionX = (rocket.x + ufo.x) / 2;
        float explosionY = (rocket.y + ufo.y) / 2;

        putimagePng(explosionX - im_blowup.getwidth() / 2, explosionY - im_blowup.getheight() / 2, &im_blowup);
        FlushBatchDraw();

        mciSendString(TEXT("open explode.mp3 alias explosion"), NULL, 0, NULL);
        mciSendString(TEXT("play explosion"), NULL, 0, NULL);

        settextstyle(50, 0, _T("Arial"));
        outtextxy(WIDTH / 2 - 100, HEIGHT / 2 - 50, _T("Game Over!"));

        FlushBatchDraw();
        stopMusic();
        Sleep(3000);
        exit(0);
    }
}

// Function to handle collision between the rocket and bullets
void handleRocketBulletCollision() {
    for (int i = 0; i < bulletNum; i++) {

        // Check collision between rocket and bullet
        if (checkCollision(rocket.x, rocket.y, rocket.width, rocket.height,
            bullet[i].x, bullet[i].y, bullet[i].radius * 2, bullet[i].radius * 2)) {

            heartCount--; // Decrease heart count when hit by a bullet

            // Remove the bullet that hit the rocket by shifting bullets
            for (int j = i; j < bulletNum - 1; j++) {
                bullet[j] = bullet[j + 1];
            }
            bulletNum--;
            i--;

            // Check if hearts reach 0 to trigger game over
            if (heartCount <= 0) {
                // Show the blowup image at the rocket's position
                putimagePng(rocket.x - im_blowup.getwidth() / 2, rocket.y - im_blowup.getheight() / 2, &im_blowup);

                FlushBatchDraw();  // Refresh the screen to show the blowup
                Sleep(1000);       // Pause to let the blowup display for a moment

                // Play explode sound
                mciSendString(TEXT("open explode.mp3 alias explosion"), NULL, 0, NULL);
                mciSendString(TEXT("play explosion"), NULL, 0, NULL);

                // Show "Game Over" text
                settextstyle(50, 0, _T("Arial"));
                outtextxy(WIDTH / 2 - 100, HEIGHT / 2 - 50, _T("Game Over!"));

                stopMusic();  // Stop the background music
                FlushBatchDraw();  // Refresh the screen to show the "Game Over!" message
                Sleep(3000);  // Pause before exiting
                exit(0);  // End the game
            }

            break;  // Exit the loop after processing the collision
        }
    }
}


// Function to update with mouse input
void updateWithInput() {
    MOUSEMSG m;
    while (MouseHit()) {
        m = GetMouseMsg();
        if (m.uMsg == WM_MOUSEMOVE)
            rocket.update(m.x, m.y);
    }
}

// Function to update without input
void updateWithoutInput() {
    static int lastSecond = 0;
    static int nowSecond = 0;
    static clock_t start = clock();
    clock_t now = clock();

    nowSecond = (int(now - start) / CLOCKS_PER_SEC);

    if (nowSecond == lastSecond + 2) {
        lastSecond = nowSecond;
        if (bulletNum < MaxBulletNum) {
            bullet[bulletNum].x = WIDTH / 2;
            bullet[bulletNum].y = 10;
            float angle = (rand() / double(RAND_MAX) - 0.5) * 0.9 * PI;
            float scalar = 2 * rand() / double(RAND_MAX) + 2;
            bullet[bulletNum].vx = scalar * sin(angle);
            bullet[bulletNum].vy = scalar * cos(angle);
            bullet[bulletNum].im_bullet = im_bullet;
            bullet[bulletNum].radius = im_bullet.getwidth() / 2;
        }
        bulletNum++;
    }

    for (int i = 0; i < bulletNum; i++)
        bullet[i].update();

    ufo.update(rocket.x, rocket.y);
}

// Initialization function
void startup() {
    srand(time(0));
    loadimage(&im_bk, _T("background.png"));
    loadimage(&im_bullet, _T("bullet.png"));
    loadimage(&im_rocket, _T("rocket.png"));
    loadimage(&im_heart, _T("heart.png"));
    loadimage(&im_ufo, _T("ufo.png"));
    loadimage(&im_blowup, _T("blowup.png"));

    rocket.im_rocket = im_rocket;
    rocket.width = im_rocket.getwidth();
    rocket.height = im_rocket.getheight();

    ufo.im_ufo = im_ufo;
    ufo.width = im_ufo.getwidth();
    ufo.height = im_ufo.getheight();
    ufo.x = WIDTH / 4;
    ufo.y = HEIGHT / 4;

    initgraph(WIDTH, HEIGHT);
    BeginBatchDraw();
}

// Function to show the graphics and handle game state
void show() {
    putimage(0, 0, &im_bk); // Draw the background
    for (int i = 0; i < bulletNum; i++) {
        bullet[i].draw();  // Draw the bullets
    }
    rocket.draw();  // Draw the rocket
    ufo.draw();     // Draw the UFO

    // Heart display
    for (int i = 0; i < heartCount; i++) {
        putimagePng(10 + i * (im_heart.getwidth() + 10), 10, &im_heart); // Display hearts
    }

    // Countdown timer (from 100 to 0)
    int countdownStart = 100;
    auto now = std::chrono::high_resolution_clock::now();
    auto elapsedSeconds = std::chrono::duration_cast<std::chrono::seconds>(now - startTime).count();
    int remainingSeconds = countdownStart - (int)elapsedSeconds;

    // Display the countdown in the format "countdown: 100"
    TCHAR timerText[50];
    if (remainingSeconds >= 0) {
        _stprintf(timerText, _T("countdown: %d"), remainingSeconds);
    }
    else {
        _stprintf(timerText, _T("countdown: 0"));  // Ensure it doesn't go below 0
    }

    settextstyle(40, 0, _T("Arial"));  // Set text style
    int textWidth = textwidth(timerText);  // Get the width of the text
    outtextxy(WIDTH - textWidth - 10, 10, timerText);  // Display countdown at top right

    handleCollision();  // Handle UFO and rocket collision
    handleRocketBulletCollision();  // Handle rocket and bullet collision
    FlushBatchDraw();  // Refresh the screen
    Sleep(10);  // Delay for smooth rendering
}


// Main game loop
int main() {
    startup();
    playMusic();

    while (true) {
        updateWithInput();
        updateWithoutInput();
        handleCollision();
        handleRocketBulletCollision();
        show();
    }

    stopMusic();
    return 0;
}