#include <graphics.h>
#include <conio.h>
#include <cstdio>
#include <time.h>
#include <stdlib.h>
#include <windows.h>

#define BOARD_COUNT 6
#define SCREEN_WIDTH 500
#define SCREEN_HEIGHT 600
#define BOARD_WIDTH 100
#define BOARD_HEIGHT 10
#define CHAR_SIZE 20
#define SPIKE_HEIGHT 30
#define SPIKE_WIDTH 15  // Width of the spikes
#define SPIKE_COUNT 3   // Number of spikes on a board
#define SPEED_INCREASE_INTERVAL 20000  // Speed increase every 20 seconds
#define SPEED_INCREMENT 1  // Speed increment value

struct Board {
    int x, y, width, speed;
    bool hasSpikes;  // Flag to indicate if the board has spikesd
};

Board boards[BOARD_COUNT];
int health = 3;
int charX, charY;  // Character position
int charSpeed = 10;
int jumpVelocity = 0;  // Velocity for jumping
bool onBoard = false;
unsigned long lastSpeedIncreaseTime = 0;  // Last time speed was increased

// Function to initialize the game elements
void initGame() {
    srand((unsigned int)time(NULL));
    for (int i = 0; i < BOARD_COUNT; i++) {
        boards[i].x = rand() % (SCREEN_WIDTH - BOARD_WIDTH);
        boards[i].y = SCREEN_HEIGHT - (i * (SCREEN_HEIGHT / BOARD_COUNT));
        boards[i].width = BOARD_WIDTH;
        boards[i].speed = 5;  // Initial speed for all boards
        boards[i].hasSpikes = false; // Start with no spikes
    }

    // Assign spikes to specific boards (e.g., board 2 and board 4)
    boards[2].hasSpikes = true;  // Second board has spikes
    boards[4].hasSpikes = true;  // Fourth board has spikes

    // Start character in the middle above the first board
    charX = boards[0].x + (BOARD_WIDTH / 2);  // Center character above the first board
    charY = boards[0].y - CHAR_SIZE;  // Position character directly above the first board
}

// Function to draw spikes on a board
void drawSpikesOnBoard(Board& board) {
    if (board.hasSpikes) {
        setfillcolor(RGB(255, 0, 0));  // Color for spikes
        for (int i = 0; i < SPIKE_COUNT; i++) {
            int spikeX = board.x + (i * (BOARD_WIDTH / SPIKE_COUNT)) + (BOARD_WIDTH / (2 * SPIKE_COUNT)) - (SPIKE_WIDTH / 2);
            int spikeY = board.y - SPIKE_HEIGHT;
            line(spikeX, board.y, spikeX + SPIKE_WIDTH / 2, spikeY);               // Left side of spike
            line(spikeX + SPIKE_WIDTH / 2, spikeY, spikeX + SPIKE_WIDTH, board.y); // Right side of spike
        }
    }
}

// Function to draw spikes at the top of the screen
void drawTopSpikes() {
    setfillcolor(RGB(255, 0, 0));  // Color for top spikes
    for (int i = 0; i < 20; i++) {
        int spikeX = 30 * i;
        int spikeY = SPIKE_HEIGHT; // Top of the screen
        line(spikeX, 0, spikeX + SPIKE_WIDTH / 2, spikeY);               // Left side of spike
        line(spikeX + SPIKE_WIDTH / 2, spikeY, spikeX + SPIKE_WIDTH, 0); // Right side of spike
    }
}

// Function to move and draw boards
void moveAndDrawBoards() {
    for (int i = 0; i < BOARD_COUNT; i++) {
        // Move the boards upwards
        boards[i].y -= boards[i].speed;
        if (boards[i].y < 0) {
            boards[i].y = SCREEN_HEIGHT - BOARD_HEIGHT;
            boards[i].x = rand() % (SCREEN_WIDTH - BOARD_WIDTH);
        }

        // Draw the boards
        setfillcolor(RGB(150, 150, 150));
        fillrectangle(boards[i].x, boards[i].y, boards[i].x + boards[i].width, boards[i].y + BOARD_HEIGHT);

        // Draw spikes on the board
        drawSpikesOnBoard(boards[i]);
    }
}

// Function to move the character
void moveCharacter() {
    // Handle horizontal movement
    if (GetAsyncKeyState('A') & 0x8000) charX -= charSpeed;
    if (GetAsyncKeyState('D') & 0x8000) charX += charSpeed;

    // Keep the character within the screen bounds
    if (charX < CHAR_SIZE) charX = CHAR_SIZE;  // Left boundary
    if (charX > SCREEN_WIDTH - CHAR_SIZE) charX = SCREEN_WIDTH - CHAR_SIZE;  // Right boundary

    // Handle jumping
    if (GetAsyncKeyState(VK_SPACE) & 0x8000 && onBoard) {
        jumpVelocity = -15;  // Set a negative jump velocity
        onBoard = false;  // Character is no longer on a board
    }

    // Update character position based on jump velocity
    charY += jumpVelocity;

    // Apply gravity if the character is not on a board
    if (!onBoard) {
        jumpVelocity += 1;  // Simulate gravity
    }

    // Prevent falling below the bottom of the screen
    if (charY > SCREEN_HEIGHT) {
        charY = SCREEN_HEIGHT;  // Keep character at the bottom
        jumpVelocity = 0;  // Reset jump velocity
    }
}

// Function to detect collision between character and boards
void detectCollision() {
    onBoard = false;  // Reset onBoard status
    for (int i = 0; i < BOARD_COUNT; i++) {
        // Check if character lands on the board
        if (charY + CHAR_SIZE >= boards[i].y && charY + CHAR_SIZE <= boards[i].y + BOARD_HEIGHT &&
            charX + CHAR_SIZE >= boards[i].x && charX - CHAR_SIZE <= boards[i].x + boards[i].width) {
            // Adjust character position to land on the board
            charY = boards[i].y - CHAR_SIZE;  // Position character directly above the board
            onBoard = true;  // Set onBoard to true

            // Check if the board has spikes
            if (boards[i].hasSpikes) {
                printf("Game Over! You hit the spikes on the board.\n");  // Print Game Over message
                health = 0;  // Set health to zero to trigger game over
            }
            jumpVelocity = 0;  // Reset jump velocity when landing
            break;  // Exit the loop after landing
        }
    }

    // Check if character touches the spikes at the top of the screen
    if (charY <= SPIKE_HEIGHT) {
        printf("Game Over! You hit the spikes at the top of the screen.\n");  // Print Game Over message
        health = 0;  // Set health to zero to trigger game over
    }
}

// Function to check if the character falls down
void checkGameOverConditions() {
    // Check if character falls below the bottom of the screen
    if (charY >= SCREEN_HEIGHT) {
        printf("Game Over! You fell off the screen.\n");  // Print Game Over message
        health = 0;  // Set health to zero to trigger game over
    }
}



// Function to place the character
void placeCharacter() {
    // Draw the character
    setfillcolor(RGB(255, 255, 0));
    fillcircle(charX, charY, CHAR_SIZE);
}

int main() {
    initgraph(SCREEN_WIDTH, SCREEN_HEIGHT);
    initGame();

    while (1) {
        cleardevice();  // Clear screen for the next frame
        drawTopSpikes();  // Draw spikes at the top of the screen
        moveAndDrawBoards();  // Move and draw boards
        moveCharacter();  // Move the character
        detectCollision();  // Detect collision with boards
        placeCharacter();  // Place character on the screen
        checkGameOverConditions();  // Check for game over conditions
        

        // Break the loop if health is zero
        if (health <= 0) {
            break;  // Exit the game loop
        }

        Sleep(20);  // Control frame rate
    }

    closegraph();  // Close the graphics window
    return 0;
}