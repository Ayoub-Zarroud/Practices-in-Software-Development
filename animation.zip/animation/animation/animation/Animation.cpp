#include <graphics.h>  
#include <conio.h>
#include <time.h>
#include "EasyXPng.h"  
#include <mmsystem.h>  // Ensure this is included for mciSendString
#pragma comment(lib,"Winmm.lib") 

#define _CRT_SECURE_NO_WARNINGS
#pragma warning (disable: 4996)

#define  WIDTH  790  
#define  HEIGHT 670  
IMAGE background;

// Function to display the background
void showBackground() {
    putimage(0, 0, &background);  // Display the stage/background
}

int main()
{
    // Initialize graphics and load background
    initgraph(WIDTH, HEIGHT);
    loadimage(&background, _T("background.png"), WIDTH, HEIGHT);  // Load the stage background
    IMAGE img[7];

    // Load the images for the girl animation (with transparent background)
    TCHAR filename[20];
    for (int i = 0; i < 7; i++) {
        _stprintf(filename, _T("girl%d.png"), i);  // Make sure girl images have transparent background
        loadimage(&img[i], filename);
    }

    // Play background music without repeat
    mciSendString(TEXT("open game_music.mp3 alias bkmusic"), NULL, 0, NULL);
    mciSendString(TEXT("play bkmusic"), NULL, 0, NULL);  // Play the music once, without repeat

    int i = 0;

    BeginBatchDraw();

    // Main game loop
    while (1)
    {
        showBackground();  // Display the stage background
        putimagePng(100, 100, &img[i]);  // Display the girl with transparency
        Sleep(200);

        i += 1;
        if (i == 7) i = 0;
        FlushBatchDraw();
    }

    EndBatchDraw();

    // Close resources and graph
    _getch();
    closegraph();

    // Stop and close the music when exiting
    mciSendString(TEXT("stop bkmusic"), NULL, 0, NULL);
    mciSendString(TEXT("close bkmusic"), NULL, 0, NULL);

    return 0;
}
