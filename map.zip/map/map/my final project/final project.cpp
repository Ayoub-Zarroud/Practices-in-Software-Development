#include <stdio.h>
#include <graphics.h>
#include "conio.h"
#include "EasyXPng.h"

#define TILE_SIZE 32  // Set tile size to 32 pixels
#define WIDTH  (30 * TILE_SIZE)  // Adjusted width (24 columns * 32 pixels per tile)
#define HEIGHT (24 * TILE_SIZE)  // Adjusted height (24 rows * 32 pixels per tile)

const int rows = 24, cols = 30;
int rowNum, colNum;

// Initialize the map with all 0's (map0.png)
int mapIndex[rows * cols] = { 0 };

int main()
{
    IMAGE map[10]; // Array size for map0, water, rocks, and rockwater images
    IMAGE run, s1, s2, s3, s4, s5, left, curve, strate, right, curveR;
    IMAGE img3, img2, img1, mod;  // Images for countdown (3.png, 2.png, 1.png)
    IMAGE img1_left, middle, img1_right; // New images for 1-left.png, middle.png, and 1-right.png
    IMAGE roof_left, roof_mid, roof_right, fin_left; // New images for roof-left.png, roof-mid.png, and roof-right.png
    IMAGE roof2_right, roof2_mid, roof2_left, step_bottomright, step_bottomleft, step_topleft, step_topright, step_midleft, step_midright; // New images for roof2-right, roof2-mid, roof2-left
    IMAGE window, right_window, water1, water2, water3, fin; // New image for window.png
    IMAGE left_corner, right_corner, pip, pip2, tree_left, tree_right, tree_topright, tree_topleft, toptree_right, toptree_left, rose;
    initgraph(WIDTH, HEIGHT);

    int i, x, y;

    loadimage(&map[0], _T("map0.png"));         // Main map image
    loadimage(&map[1], _T("water.png"));        // Water image
    loadimage(&map[2], _T("rock0.png"));        // Rock images
    loadimage(&map[3], _T("rock1.png"));
    loadimage(&map[4], _T("rock2.png"));
    loadimage(&map[5], _T("rock3.png"));
    loadimage(&map[6], _T("rockwater0.png"));   // Rockwater images
    loadimage(&map[7], _T("rockwater1.png"));
    loadimage(&map[8], _T("rockwater2.png"));
    loadimage(&map[9], _T("rockwater3.png"));
    loadimage(&run, _T("rue.png"));             // Run image
    loadimage(&s1, _T("s1.png"));               // s1 image
    loadimage(&s2, _T("s2.png"));               // s2 image
    loadimage(&s3, _T("s3.png"));               // s3 image
    loadimage(&s4, _T("s4.png"));               // s4 image
    loadimage(&s5, _T("s5.png"));               // s5 image
    loadimage(&left, _T("left.png"));           // Load left.png image
    loadimage(&curve, _T("curve.png"));         // Load curve.png image
    loadimage(&strate, _T("strate.png"));       // Load strate.png image
    loadimage(&right, _T("right.png"));         // Load right.png image
    loadimage(&curveR, _T("curveR.png"));       // Load curveR.png image
    loadimage(&img3, _T("3.png"));              // Load countdown images
    loadimage(&img2, _T("2.png"));
    loadimage(&img1, _T("1.png"));
    loadimage(&img1_left, _T("1-left.png"));    // Load 1-left.png image
    loadimage(&middle, _T("middle.png"));       // Load middle.png image
    loadimage(&img1_right, _T("1-right.png"));  // Load 1-right.png image
    loadimage(&roof_left, _T("roof-left.png")); // Load roof-left.png image
    loadimage(&roof_mid, _T("roof-mid.png"));   // Load roof-mid.png image
    loadimage(&roof_right, _T("roof-right.png"));// Load roof-right.png image
    loadimage(&roof2_right, _T("roof2-right.png")); // Load roof2 images
    loadimage(&roof2_mid, _T("roof2-mid.png"));
    loadimage(&roof2_left, _T("roof2-left.png"));
    loadimage(&window, _T("window.png"));       // Load window.png
    loadimage(&right_window, _T("right-window.png")); // Load right-window.png
    loadimage(&left_corner, _T("left-corner.png"));
    loadimage(&right_corner, _T("right-corner.png"));
    loadimage(&pip, _T("pip.png"));
    loadimage(&pip2, _T("pip2.png"));
    loadimage(&tree_left, _T("tree-left.png"));
    loadimage(&tree_right, _T("tree-right.png"));
    loadimage(&tree_topright, _T("tree-topright.png"));
    loadimage(&tree_topleft, _T("tree-topleft.png"));
    loadimage(&toptree_right, _T("toptree-right.png"));
    loadimage(&toptree_left, _T("toptree-left.png"));
    loadimage(&rose, _T("rose.png"));
    loadimage(&water1, _T("water1.png"));
    loadimage(&water2, _T("water2.png"));
    loadimage(&water3, _T("water3.png"));
    loadimage(&fin, _T("fin.png"));
    loadimage(&mod, _T("mod.png"));
    loadimage(&step_bottomright, _T("step-bottomright.png"));
    loadimage(&step_bottomleft, _T("step-bottomleft.png"));
    loadimage(&step_topright, _T("step-topright.png"));
    loadimage(&step_topleft, _T("step-topleft.png"));
    loadimage(&step_midright, _T("step-midright.png"));
    loadimage(&step_midleft, _T("step-midleft.png"));
    loadimage(&fin_left, _T("fin-left.png"));

    // Draw the map based on mapIndex values
    for (i = 0; i < rows * cols; i++)
    {
        rowNum = i / cols;
        colNum = i % cols;
        x = colNum * TILE_SIZE;
        y = rowNum * TILE_SIZE;
        putimage(x, y, &map[mapIndex[i]]);
    }

    // Draw water.png on the bottom 6 rows
    for (int r = rows - 6; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            x = c * TILE_SIZE;
            y = r * TILE_SIZE;
            putimage(x, y, &map[1]); // Draw water.png on top of map0.png
        }
    }

    // Fill row 17 with water.png from columns 0 to 10
    for (int c = 0; c <= 10; c++)
    {
        x = c * TILE_SIZE;
        y = 17 * TILE_SIZE;
        putimage(x, y, &map[1]); // Replace with water.png
    }

    // Fill row 17 with water.png from columns 12 to 24
    for (int c = 12; c < cols; c++)
    {
        x = c * TILE_SIZE;
        y = 17 * TILE_SIZE;
        putimage(x, y, &map[1]); // Replace with water.png
    }

    // Place fixed rock images in the top 18 rows
    int rockPositions[4][2] = { {2, 5}, {4, 12}, {10, 8}, {15, 16} }; // Fixed positions for rock images
    for (int rockNum = 2; rockNum <= 5; rockNum++) {
        int r = rockPositions[rockNum - 2][0]; // Row for each rock
        int c = rockPositions[rockNum - 2][1]; // Column for each rock

        x = c * TILE_SIZE;
        y = r * TILE_SIZE;
        putimage(x, y, &map[rockNum]); // Place each rock image at its fixed position
    }

    // Place fixed rockwater images in the bottom 6 rows (water area)
    int rockwaterPositions[4][2] = { {19, 3}, {20, 10}, {22, 15}, {23, 20} }; // Fixed positions for rockwater images
    for (int rockwaterNum = 6; rockwaterNum <= 9; rockwaterNum++) {
        int r = rockwaterPositions[rockwaterNum - 6][0]; // Row for each rockwater
        int c = rockwaterPositions[rockwaterNum - 6][1]; // Column for each rockwater

        x = c * TILE_SIZE;
        y = r * TILE_SIZE;
        putimage(x, y, &map[rockwaterNum]); // Place each rockwater image at its fixed position
    }

    // Place run.png from matrix 13,11 to 16,11
    for (int r = 13; r <= 16; r++)
    {
        x = 11 * TILE_SIZE;   // Column 11
        y = r * TILE_SIZE;    // Rows 13 to 16
        putimage(x, y, &run); // Place run.png in each cell
    }

    // Place left.png in row 17, column 10
    x = 10 * TILE_SIZE; // Column 10
    y = 17 * TILE_SIZE; // Row 17
    putimage(x, y, &left); // Place left.png

    // Place curve.png in row 16, column 10
    x = 10 * TILE_SIZE; // Column 10
    y = 16 * TILE_SIZE; // Row 16
    putimage(x, y, &curve); // Place curve.png

    // Place s1.png in row 17, column 11
    x = 11 * TILE_SIZE;
    y = 17 * TILE_SIZE;
    putimage(x, y, &s1);

    // Place s3.png in row 18, column 11
    x = 11 * TILE_SIZE;
    y = 18 * TILE_SIZE;
    putimage(x, y, &s3);

    // Place s2.png in row 19, column 11
    x = 11 * TILE_SIZE;
    y = 19 * TILE_SIZE;
    putimage(x, y, &s2);

    // Place s4.png from columns 5 to 10 in row 18
    for (int c = 5; c <= 10; c++)
    {
        x = c * TILE_SIZE; // Columns 5 to 10
        y = 18 * TILE_SIZE; // Row 18
        putimage(x, y, &s4); // Place s4.png
    }

    // Place s5.png from columns 5 to 10 in row 19
    for (int c = 5; c <= 10; c++)
    {
        x = c * TILE_SIZE; // Columns 5 to 10
        y = 19 * TILE_SIZE; // Row 19
        putimage(x, y, &s5); // Place s5.png
    }

    // Place s4.png from columns 12 to 16 in row 18
    for (int c = 12; c <= 16; c++)
    {
        x = c * TILE_SIZE; // Columns 12 to 16
        y = 18 * TILE_SIZE; // Row 18
        putimage(x, y, &s4); // Place s4.png
    }

    // Place s5.png from columns 12 to 16 in row 19
    for (int c = 12; c <= 16; c++)
    {
        x = c * TILE_SIZE; // Columns 12 to 16
        y = 19 * TILE_SIZE; // Row 19
        putimage(x, y, &s5); // Place s5.png
    }

    // Place water in row 17 from columns 0 to 10
    for (int c = 0; c <= 10; c++)
    {
        x = c * TILE_SIZE; // Columns 0 to 10
        y = 17 * TILE_SIZE; // Row 17
        putimage(x, y, &map[1]); // Draw water.png
    }

    // Place water in row 17 from columns 12 to 24
    for (int c = 12; c < cols; c++)
    {
        x = c * TILE_SIZE; // Columns 12 to 24
        y = 17 * TILE_SIZE; // Row 17
        putimage(x, y, &map[1]); // Draw water.png
    }

    // Place left.png in 10,17
    x = 10 * TILE_SIZE; // Column 10
    y = 17 * TILE_SIZE; // Row 17
    putimage(x, y, &left); // Place left.png

    // Place curve.png in 10,16
    x = 10 * TILE_SIZE; // Column 10
    y = 16 * TILE_SIZE; // Row 16
    putimage(x, y, &curve); // Place curve.png

    // Place strate.png from columns 0 to 9 in row 16
    for (int c = 0; c <= 9; c++)
    {
        x = c * TILE_SIZE; // Columns 0 to 9
        y = 16 * TILE_SIZE; // Row 16
        putimage(x, y, &strate); // Place strate.png
    }

    // Place strate.png from columns 13 to 24 in row 16
    for (int c = 13; c < cols; c++)
    {
        x = c * TILE_SIZE; // Columns 13 to 24
        y = 16 * TILE_SIZE; // Row 16
        putimage(x, y, &strate); // Place strate.png
    }

    // Place curveR.png in row 16, column 12
    x = 12 * TILE_SIZE; // Column 12
    y = 16 * TILE_SIZE; // Row 16
    putimage(x, y, &curveR); // Place curveR.png

    // Place right.png in row 17, column 12
    x = 12 * TILE_SIZE; // Column 12
    y = 17 * TILE_SIZE; // Row 17
    putimage(x, y, &right); // Place right.png

    // Place countdown images (3.png, 2.png, 1.png)
    x = 14 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &img3); // Place 3.png at (11,14)

    x = 15 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &img2); // Place 2.png at (11,15)

    x = 16 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &img1); // Place 1.png at (11,16)

    // Place 1-left.png, middle.png, 1-right.png at (10,14), (10,15), and (10,16) respectively
    x = 14 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &img1_left); // Place 1-left.png

    x = 15 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &middle); // Place middle.png

    x = 16 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &img1_right); // Place 1-right.png

    // Place roof images at (9,14), (9,15), (9,16)
    x = 14 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &roof_left); // Place roof-left.png

    x = 15 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &roof_mid); // Place roof-mid.png

    x = 16 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &roof_right); // Place roof-right.png

    // Place roof2 images at (8,14), (8,15), and (8,16)
    x = 14 * TILE_SIZE;
    y = 8 * TILE_SIZE;
    putimage(x, y, &roof2_left); // Place roof2-left.png

    x = 15 * TILE_SIZE;
    y = 8 * TILE_SIZE;
    putimage(x, y, &roof2_mid); // Place roof2-mid.png

    x = 16 * TILE_SIZE;
    y = 8 * TILE_SIZE;
    putimage(x, y, &roof2_right); // Place roof2-right.png

    // Place window.png at (8,17)
    x = 17 * TILE_SIZE; // Column 17
    y = 8 * TILE_SIZE; // Row 8
    putimage(x, y, &window); // Place window.png at (8,17)

    // Place window.png at (8,18)
    x = 18 * TILE_SIZE; // Column 18
    y = 8 * TILE_SIZE; // Row 8
    putimage(x, y, &window); // Place window.png at (8,18)

    // Place right-window.png at (8,19)
    x = 19 * TILE_SIZE; // Column 19
    y = 8 * TILE_SIZE; // Row 8
    putimage(x, y, &right_window); // Place right-window.png at (8,19)

    // Place countdown images (3.png, 2.png, 1.png)
    x = 17 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &img1_left); // Place 1-left.png
    

    x = 18 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &middle); // Place middle.png
    

    x = 19 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &img1_right); // Place 1-right.png

    x = 17 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &img2); 

    x = 18 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &img2);

    x = 19 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &img2);

    x = 15 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &roof2_mid); 

    x = 16 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &roof2_mid); 

    x = 17 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &roof2_mid); 

    x = 18 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &roof2_mid); 

    x = 14 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &left_corner); 


    x = 19 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &right_corner); 

    x = 20 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &pip);

    x = 21 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &pip);

    x = 22 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &pip);

    x = 23 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &pip);

    x = 20 * TILE_SIZE;
    y = 7 * TILE_SIZE;
    putimage(x, y, &pip);

    x = 20 * TILE_SIZE;
    y = 8 * TILE_SIZE;
    putimage(x, y, &map[1]);

    x = 20 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &water1);

    x = 20 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &water2);

    x = 20 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &map[1]);

    x = 20 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &s1);

    x = 20 * TILE_SIZE;
    y = 13 * TILE_SIZE;
    putimage(x, y, &water3);

    x = 20 * TILE_SIZE;
    y = 14 * TILE_SIZE;
    putimage(x, y, &map[1]);

    x = 20 * TILE_SIZE;
    y = 15 * TILE_SIZE;
    putimage(x, y, &map[1]);

    x = 20 * TILE_SIZE;
    y = 16 * TILE_SIZE;
    putimage(x, y, &map[1]);

    x = 19 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &fin);

    x = 18 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 17 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 16 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 15 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 14 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 13 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 12 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &fin_left);

    x = 11 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &mod);

    x = 19 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &tree_right);

    x = 18 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &tree_left);

    x = 19 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &tree_topright);

    x = 18 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &tree_topleft);

    x = 18 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &toptree_left);

    x = 19 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &toptree_right);

    x = 17 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &rose);

    x = 7 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &step_bottomright);

    x = 6 * TILE_SIZE;
    y = 11 * TILE_SIZE;
    putimage(x, y, &step_bottomleft);

    x = 7 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &step_midright);

    x = 6 * TILE_SIZE;
    y = 10 * TILE_SIZE;
    putimage(x, y, &step_midleft);

    x = 7 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &step_topright);

    x = 6 * TILE_SIZE;
    y = 9 * TILE_SIZE;
    putimage(x, y, &step_topleft);

    x = 10 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &fin);

    x = 9 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 8 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 7 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &pip2);

    x = 6 * TILE_SIZE;
    y = 12 * TILE_SIZE;
    putimage(x, y, &fin_left);

    _getch();
    return 0;
}
