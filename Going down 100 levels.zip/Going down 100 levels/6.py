import pgzrun  # 
import random  # 

WIDTH = 600    # 
HEIGHT = 800   # 
playerSpeed = 5  # 
brickSpeed = 2   # 
isLoose = False  # 

alien = Actor('alien')  # 
alien.x = WIDTH/2      # 
alien.y = HEIGHT/5     # 

bricks = []  # 
for i in range(5):
    brick = Actor('brick')  # 
    brick.pos = 100*(i+1), 150*(i+1)    # 
    bricks.append(brick)  # 

def draw():    # 
    screen.clear()  # 
    alien.draw()  # 
    for brick in bricks:  # 
        brick.draw()  # 
    if isLoose:  # 
        screen.draw.text("Fail！", (80, HEIGHT/2-100),
                         fontsize=100, fontname='s', color='red')

def update():  #
    global isLoose, playerSpeed, brickSpeed

    isPlayerOnGround = False  # 
    for brick in bricks: # 
        # 
        if abs(alien.bottom-brick.top) < 5  \
            and brick.left - alien.left < alien.width*2/3 \
            and alien.right - brick.right < alien.width*2/3:
            
            isPlayerOnGround = True  # 
            alien.bottom = brick.top  # 

            if keyboard.left:  # 
                alien.x = alien.x - playerSpeed  # 
            if keyboard.right:  # 
                alien.x = alien.x + playerSpeed  # 

    if not isPlayerOnGround:
        alien.y += 5  # 

    for birck in bricks: # 
        birck.y -= brickSpeed

    if bricks[0].top < 10: # 
        del bricks[0]  # 
        brick = Actor('brick') # 
        brick.x = random.randint(100, 500) # 
        brick.y = HEIGHT # 
        bricks.append(brick) # 

    if alien.top < 0 or alien.bottom > HEIGHT:  # 
        playerSpeed = 0  # 
        brickSpeed = 0   # 
        isLoose = True   # 

pgzrun.go()  # 