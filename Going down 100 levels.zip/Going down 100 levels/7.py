import pgzrun
import random

WIDTH = 600
HEIGHT = 800
playerSpeed = 3  # Reduced the movement speed
brickSpeed = 2
isLoose = False
score = 0
paused = False  # Variable to track the paused state

# Define jump variables
jumping = False
jumpSpeed = 15  # Vertical speed for jump
gravity = 1     # Gravity effect

alien = Actor('alien')
alien.x = WIDTH / 2
alien.y = HEIGHT / 5
lastAlienY = alien.y

bricks = []
spikes = []  # List to hold spikes

# Initialize bricks and spikes
for i in range(5):
    brick = Actor('brick')
    brick.pos = 100 * (i + 1), 150 * (i + 1)
    bricks.append(brick)

    # Use weighted random choice for spike placement (20% chance for spikes)
    if random.choices([True, False], weights=[20, 80])[0]:  # 20% chance for a spike
        spike = Actor('spike')
        spike.pos = brick.x, brick.top - spike.height / 2
        spikes.append(spike)

def draw():
    screen.clear()
    alien.draw()
    for brick in bricks:
        brick.draw()
    for spike in spikes:
        spike.draw()
    screen.draw.text("Survived for " + str(score) + " levels！",
                     (400, 20), fontsize=25, fontname='s', color='white')
    if isLoose:
        screen.draw.text("Fail！", (80, HEIGHT / 2 - 100),
                         fontsize=100, fontname='s', color='red')
    if paused:
        screen.draw.text("Paused", (WIDTH / 2 - 100, HEIGHT / 2 - 50),
                         fontsize=60, fontname='s', color='yellow')

def update():
    global isLoose, playerSpeed, brickSpeed, score, lastAlienY, jumping, jumpSpeed, gravity, paused

    if paused:
        return  # Stop updating the game while paused

    isPlayerOnGround = False
    for brick in bricks:
        # Check if the player is near the top of the brick
        if abs(alien.bottom - brick.top) < 5 and brick.left - alien.left < alien.width * 2 / 3 and alien.right - brick.right < alien.width * 2 / 3:
            alien.image = 'alien'
            isPlayerOnGround = True
            alien.bottom = brick.top  # Set the player on top of the brick
            if lastAlienY < alien.y:
                score += 1

            # Move left or right while on ground
            if keyboard.left:
                alien.x = alien.x - playerSpeed
            if keyboard.right:
                alien.x = alien.x + playerSpeed

    # Jump functionality - Allow jump while moving left or right
    if keyboard.space and not jumping and isPlayerOnGround:
        jumping = True
        jumpSpeed = 15  # Reset jump speed when jumping

    # Apply gravity and jump mechanics
    if jumping:
        alien.y -= jumpSpeed  # Move up
        jumpSpeed -= gravity  # Decrease jump speed over time to simulate gravity
        if jumpSpeed <= 0:  # Once jumpSpeed reaches 0, start falling
            jumping = False

    # If the character is falling, apply gravity and check for brick collisions
    if not isPlayerOnGround and not jumping:
        alien.image = 'alien_falling'
        alien.y += 5  # Falling speed

        # Check if the feet are colliding with any brick
        for brick in bricks:
            if alien.colliderect(brick) and alien.bottom <= brick.top + 5:  # Detect only the bottom part of the character
                alien.bottom = brick.top  # Land on top of the brick
                isPlayerOnGround = True
                jumping = False  # Stop falling
                break

    # Allow movement while in the air if no brick collision
    if keyboard.left:
        alien.x = alien.x - playerSpeed
    if keyboard.right:
        alien.x = alien.x + playerSpeed

    lastAlienY = alien.y

    # Scroll bricks and spikes
    for brick in bricks:
        brick.y -= brickSpeed

    for spike in spikes:
        spike.y -= brickSpeed

    if bricks[0].top < 10:
        del bricks[0]
        brick = Actor('brick')
        brick.x = random.randint(100, 500)
        brick.y = HEIGHT
        bricks.append(brick)

        # Use weighted random choice for spike placement (20% chance for spikes)
        if random.choices([True, False], weights=[20, 80])[0]:  # 20% chance for a spike
            spike = Actor('spike')
            spike.pos = brick.x, brick.top - spike.height / 2
            spikes.append(spike)

        # Remove the oldest spike if it has scrolled off the screen
        if spikes and spikes[0].y < 0:
            spikes.pop(0)

    # Check for collision with spikes
    for spike in spikes:
        if alien.colliderect(spike):
            playerSpeed = 0
            brickSpeed = 0
            isLoose = True

    if alien.top < 0 or alien.bottom > HEIGHT:
        playerSpeed = 0
        brickSpeed = 0
        isLoose = True

def on_key_down(key):
    global paused
    if key == keys.P:
        paused = not paused  # Toggle the paused state

pgzrun.go()
