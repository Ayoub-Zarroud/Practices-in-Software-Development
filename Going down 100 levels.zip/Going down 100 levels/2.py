import pgzrun  # 

WIDTH = 600    # 
HEIGHT = 800   # 
playerSpeed = 5 # 

alien = Actor('alien')  # 
alien.x = WIDTH/2      # 
alien.y = HEIGHT/2   # 

def draw():    # 
    screen.clear()  # 
    alien.draw()  #

def update():  # 
    if keyboard.left: # 
        alien.x = alien.x - playerSpeed  #
    if keyboard.right:  # 
        alien.x = alien.x + playerSpeed  # 

pgzrun.go()  # 
