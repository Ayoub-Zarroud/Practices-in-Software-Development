
import pgzrun  # 

WIDTH = 600    # 
HEIGHT = 800   # 

alien = Actor('alien')  # 
alien.x = WIDTH/2      # 
alien.y = HEIGHT/2   # 

def draw():    # 
    #screen.clear()  # 
    alien.draw()  #

pgzrun.go()  # 
