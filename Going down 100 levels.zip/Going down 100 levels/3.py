import pgzrun  # 

WIDTH = 600    # 
HEIGHT = 800   # 
playerSpeed = 5 # 

alien = Actor('alien')  # 
alien.x = WIDTH/2      # 
alien.y = HEIGHT/2   # 
brick = Actor('brick')  # 
brick.pos = 300, 600    # 

def draw():    # 
    screen.clear()  # 
    alien.draw()  #
    brick.draw()  # 

def update():  # 
    # check if the alien is standing within the brick
    if abs(alien.bottom-brick.top) < 5  \
        and brick.left - alien.left < alien.width*2/3 \
        and alien.right - brick.right < alien.width*2/3:
        if keyboard.left:  # 
            alien.x = alien.x - playerSpeed  # 
        if keyboard.right:  # 
            alien.x = alien.x + playerSpeed  # 
    else:  # 
        alien.y += 5  # or fall

pgzrun.go()  # 