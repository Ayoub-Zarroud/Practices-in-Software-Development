import pgzrun  # 

WIDTH = 600    # 
HEIGHT = 800   # 
playerSpeed = 5 # 

alien = Actor('alien')  # 
alien.x = WIDTH/2      # 
alien.y = HEIGHT/5     # 

bricks = []  # 
for i in range(5):
    brick = Actor('brick')  # 
    brick.pos = 100*(i+1), 150*(i+1)    # 
    bricks.append(brick)  # 

def draw():    # 
    screen.clear()  # 
    alien.draw()  # 
    for brick in bricks:  # 
        brick.draw()  # 

def update():  # 
    isPlayerOnGround = False  # 
    for brick in bricks: # 
        # 
        if abs(alien.bottom-brick.top) < 5  \
            and brick.left - alien.left < alien.width*2/3 \
            and alien.right - brick.right < alien.width*2/3:
            isPlayerOnGround = True  # 
            if keyboard.left:  # 
                alien.x = alien.x - playerSpeed  # 
            if keyboard.right:  # 
                alien.x = alien.x + playerSpeed  # 
    if not isPlayerOnGround:
        alien.y += 5  # 

pgzrun.go()  # 
