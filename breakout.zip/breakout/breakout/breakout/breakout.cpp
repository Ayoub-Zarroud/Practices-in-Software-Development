#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <windows.h>

#define ROWS 6
#define COLS 5

int main() {
    int r = 10;
    int x = 300, y = 580;
    int vx = 8, vy = 10;
    int w = 90, h = 40;
    int xs, ys;
    int gap = 5;
    int boardX = 250, boardY = 580, boardW = 100, boardH = 20;
    int missCount = 0;
    int bricksHit = 0;
    bool dropRedBall = false;
    int redBallX = 0, redBallY = -50;
    int redBallVy = 5;
    bool buffActive = false;
    DWORD buffStartTime = 0;

    bool bricks[ROWS][COLS];

    int brickColors[ROWS][COLS] = {
        {RGB(255, 0, 0), RGB(0, 255, 0), RGB(0, 0, 255), RGB(255, 255, 0), RGB(255, 165, 0)},
        {RGB(255, 20, 147), RGB(75, 0, 130), RGB(0, 255, 255), RGB(255, 105, 180), RGB(0, 100, 0)},
        {RGB(0, 0, 139), RGB(255, 99, 71), RGB(173, 216, 230), RGB(255, 69, 0), RGB(139, 69, 19)},
        {RGB(0, 128, 128), RGB(220, 20, 60), RGB(70, 130, 180), RGB(128, 0, 128), RGB(255, 218, 185)},
        {RGB(85, 107, 47), RGB(255, 222, 173), RGB(138, 43, 226), RGB(192, 192, 192), RGB(255, 228, 225)},
        {RGB(218, 165, 32), RGB(255, 239, 213), RGB(0, 191, 255), RGB(144, 238, 144), RGB(106, 90, 205)}
    };

    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            bricks[i][j] = true;
        }
    }

    initgraph(600, 600);
    setbkcolor(RGB(200, 200, 200));
    cleardevice();

    BeginBatchDraw();

    while (1) {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (bricks[i][j]) {
                    xs = i * w;
                    ys = j * h;
                    setfillcolor(brickColors[i][j]);
                    fillrectangle(gap * (i + 1) + xs, gap * (j + 1) + ys,
                        gap * (i + 1) + xs + w, gap * (j + 1) + ys + h);
                }
            }
        }

        setfillcolor(RGB(128, 0, 128));
        fillrectangle(boardX, boardY, boardX + boardW, boardY + boardH);

        if (y + r >= boardY && x >= boardX && x <= boardX + boardW) {
            vy = -vy;
        }

        if (y + r >= 600) {
            missCount++;
            y = 300;
            x = 300;
            vy = -vy;
        }

        if (missCount >= 3) {
            settextcolor(RGB(0, 0, 255));
            settextstyle(60, 0, _T("Arial"));
            outtextxy(270, 400, _T("Lose"));
            break;
        }

        if (y < r) vy = -vy;
        if (x > 600 - r || x < r) vx = -vx;

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (bricks[i][j]) {
                    int brickLeft = gap * (i + 1) + i * w;
                    int brickRight = brickLeft + w;
                    int brickTop = gap * (j + 1) + j * h;
                    int brickBottom = brickTop + h;

                    if (x + r >= brickLeft && x - r <= brickRight && y + r >= brickTop && y - r <= brickBottom) {
                        bricks[i][j] = false;
                        vy = -vy;
                        bricksHit++;

                        if (bricksHit % 5 == 0) {
                            dropRedBall = true;
                            redBallX = rand() % (600 - 2 * r) + r;
                            redBallY = 0;
                        }
                    }
                }
            }
        }

        x = x + vx;
        y = y + vy;

        setfillcolor(RGB(128, 0, 0));
        fillcircle(x, y, r);

        if (dropRedBall) {
            setfillcolor(RGB(255, 0, 0));
            fillcircle(redBallX, redBallY, r);
            redBallY += redBallVy;

            if (redBallY + r >= boardY && redBallX >= boardX && redBallX <= boardX + boardW) {
                boardW *= 2;
                buffActive = true;
                buffStartTime = GetTickCount();
                dropRedBall = false;
            }

            if (redBallY > 600) {
                dropRedBall = false;
            }
        }

        if (buffActive && (GetTickCount() - buffStartTime > 10000)) {
            boardW /= 2;
            buffActive = false;
        }

        if (GetAsyncKeyState('A') & 0x8000 && boardX > 0) {
            boardX -= 10;
        }
        if (GetAsyncKeyState('D') & 0x8000 && boardX < 600 - boardW) {
            boardX += 10;
        }

        FlushBatchDraw();
        Sleep(30);
        cleardevice();
    }

    EndBatchDraw();

    _getch();

    closegraph();
    return 0;
}
