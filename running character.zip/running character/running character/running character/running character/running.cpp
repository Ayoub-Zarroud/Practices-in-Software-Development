#include <graphics.h>
#include <windows.h> // For GetAsyncKeyState
#include "EasyXPng.h"

#define WIDTH  640
#define HEIGHT 480

int main() {
    IMAGE im_bk;          // Background image
    IMAGE im_house;       // House image
    TCHAR filename[20];   // Buffer for filenames

    IMAGE imgRight[8], imgLeft[8], imgUp[8], imgDown[8];

    // Initialize the graphics window
    initgraph(WIDTH, HEIGHT);

    // Load sprite images for each direction
    for (int i = 0; i < 8; i++) {
        _stprintf_s(filename, _T("gr%d.png"), i); // Right
        loadimage(&imgRight[i], filename);

        _stprintf_s(filename, _T("gl%d.png"), i); // Left
        loadimage(&imgLeft[i], filename);

        _stprintf_s(filename, _T("gu%d.png"), i); // Up
        loadimage(&imgUp[i], filename);

        _stprintf_s(filename, _T("gd%d.png"), i); // Down
        loadimage(&imgDown[i], filename);
    }

    // Load background and house images
    loadimage(&im_bk, _T("bg.png"));
    loadimage(&im_house, _T("house.png"));

    // Positions for houses
    int houseX[1] = { 10 }; // X positions for houses
    int houseY = 40;        // Y position for houses

    // Character initial position and movement
    int x = WIDTH / 2, y = HEIGHT / 2; // Start in the center of the screen
    int dx_movement = 8;               // Horizontal movement speed
    int dy_movement = 8;               // Vertical movement speed
    int i = 0;                         // Animation frame index

    enum Direction { RIGHT, LEFT, UP, DOWN } direction = RIGHT;

    // Start batch drawing for smooth rendering
    BeginBatchDraw();
    while (1) {
        // Draw the background
        putimage(0, 0, &im_bk);

        // Draw houses
        for (int j = 0; j < 1; j++) {
            putimagePng(houseX[j], houseY, &im_house);
        }

        // Draw the character based on the direction
        switch (direction) {
        case UP:
            putimagePng(x, y, &imgUp[i]);
            break;
        case DOWN:
            putimagePng(x, y, &imgDown[i]);
            break;
        case LEFT:
            putimagePng(x, y, &imgLeft[i]);
            break;
        case RIGHT:
            putimagePng(x, y, &imgRight[i]);
            break;
        }

        // Handle input for character movement
        if (GetAsyncKeyState(VK_UP) & 0x8000) {
            y -= dy_movement;
            direction = UP;
        }
        if (GetAsyncKeyState(VK_DOWN) & 0x8000) {
            y += dy_movement;
            direction = DOWN;
        }
        if (GetAsyncKeyState(VK_LEFT) & 0x8000) {
            x -= dx_movement;
            direction = LEFT;
        }
        if (GetAsyncKeyState(VK_RIGHT) & 0x8000) {
            x += dx_movement;
            direction = RIGHT;
        }

        // Wrap around screen edges
        if (x < -imgRight[i].getwidth()) {
            x = WIDTH; // Wrap to the right
        }
        else if (x > WIDTH) {
            x = -imgRight[i].getwidth(); // Wrap to the left
        }
        if (y < 0) y = 0; // Prevent going above the screen
        if (y > HEIGHT - imgRight[i].getheight()) y = HEIGHT - imgRight[i].getheight(); // Prevent going below the screen

        // Update the animation frame
        i = (i + 1) % 8;

        // Delay and render
        Sleep(65);
        FlushBatchDraw();
    }

    // End the program
    EndBatchDraw();
    closegraph();
    return 0;
}
