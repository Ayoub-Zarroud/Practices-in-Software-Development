#include <graphics.h>
#include <conio.h>
#include <vector>
#include <random>
#include <sstream>           // For intToString function
#include "Timer.h"
#include "EasyXPng.h"

const int WIDTH = 800;
const int HEIGHT = 600;
const int NUM_LAND_BLOCKS = 7;
const int MAX_BATS = 2;              // Maximum number of bats on screen
const float BAT_SPAWN_INTERVAL = 3.0f; // Time interval between each bat spawn
const float BAT_SPEED = 3.0f;           // Speed at which bats move to the left

std::random_device rd;
std::mt19937 gen(rd());
std::uniform_int_distribution<> distr(0, NUM_LAND_BLOCKS - 1);

int dx_1 = 0, dx_2 = 0, vy = 0, g = 1, y; // Movement and physics variables
int heights[] = { 300, 340, 380, 420, 460, 500, 540 };
int landHeights[NUM_LAND_BLOCKS];

struct Sprite {
    IMAGE img;
    int x, y;
};

Sprite spriteBk, spriteLand, spriteJump, spriteRun[8], spriteBat[5];
bool gameOver = false;

struct Bat {
    Sprite sprite;
    int platformIndex;
    int animationIndex;
    bool active;
    float spawnTimer;
};

std::vector<Bat> bats(MAX_BATS);

// Function to convert integer to string
std::string intToString(int num) {
    std::ostringstream ss;
    ss << num;
    return ss.str();
}

void loadImages() {
    // Load background and land images
    loadimage(&spriteBk.img, "landscape1.png");  // Background image
    loadimage(&spriteLand.img, "land.png");      // Land image
    loadimage(&spriteJump.img, "jumpright.png"); // Jump image

    // Load running images without specifying dimensions
    for (int i = 0; i < 8; i++) {
        std::string path = "runright" + intToString(i) + ".png";
        loadimage(&spriteRun[i].img, path.c_str());  // Character running frames
    }

    // Load bat images without specifying dimensions
    for (int i = 0; i < 5; i++) {
        std::string path = "bat" + intToString(i) + ".png";
        loadimage(&spriteBat[i].img, path.c_str());  // Bat frames
    }
}


void initGame() {
    // Set random heights for land blocks
    for (int i = 0; i < NUM_LAND_BLOCKS; i++) {
        int randIndex = distr(gen);
        landHeights[i] = heights[randIndex];
    }

    // Initialize bats
    for (int i = 0; i < MAX_BATS; i++) {
        bats[i].sprite = spriteBat[0];
        bats[i].platformIndex = -1;
        bats[i].animationIndex = 0;
        bats[i].active = false;
        bats[i].spawnTimer = BAT_SPAWN_INTERVAL * (i + 1);
    }

    // Set initial character position
    y = heights[0] - spriteRun[0].img.getheight();
}

void drawSprite(Sprite& sprite) {
    putimagePng(sprite.x, sprite.y, &sprite.img);
}

int main() {
    initgraph(WIDTH, HEIGHT);
    Timer timer;

    // Load all images before starting the game
    loadImages();
    initGame();

    int animationHandlerIndex = 0;
    bool onLand = false;

    while (!gameOver) {
        // Clear screen
        cleardevice();

        // Draw background and move it
        spriteBk.x = dx_1;
        spriteBk.y = 0;
        drawSprite(spriteBk);
        dx_1 -= 2;
        if (dx_1 <= -1200) dx_1 = 0;

        // Draw land blocks
        for (int j = 0; j < NUM_LAND_BLOCKS; j++) {
            spriteLand.x = j * 100 + dx_2;
            spriteLand.y = landHeights[j];
            drawSprite(spriteLand);
        }
        dx_2 -= 3;
        if (dx_2 <= -100) {
            dx_2 = 0;
            for (int j = 0; j < NUM_LAND_BLOCKS - 1; j++) {
                landHeights[j] = landHeights[j + 1];
            }
            landHeights[NUM_LAND_BLOCKS - 1] = heights[distr(gen)];
        }

        // Physics for character
        vy += g;
        y += vy;

        if (y > HEIGHT) {
            gameOver = true;
            y = HEIGHT;
        }

        // Collision with land
        onLand = false;
        for (int j = 0; j < NUM_LAND_BLOCKS; j++) {
            if (y + spriteRun[0].img.getheight() >= landHeights[j] &&
                y <= landHeights[j] + spriteLand.img.getheight() &&
                WIDTH / 4 >= j * 100 + dx_2 &&
                WIDTH / 4 <= j * 100 + dx_2 + spriteLand.img.getwidth()) {
                onLand = true;
                y = landHeights[j] - spriteRun[0].img.getheight();
                vy = 0;
                break;
            }
        }

        if (animationHandlerIndex > 7) animationHandlerIndex = 0;

        // Draw character
        if (onLand) {
            spriteRun[animationHandlerIndex].x = WIDTH / 4;
            spriteRun[animationHandlerIndex].y = y;
            drawSprite(spriteRun[animationHandlerIndex]);
        }
        else {
            spriteJump.x = WIDTH / 4;
            spriteJump.y = y;
            drawSprite(spriteJump);
        }

        // Spawn and move bats
        for (auto& bat : bats) {
            if (!bat.active) {
                bat.spawnTimer -= 1;
                if (bat.spawnTimer <= 0) {
                    bat.platformIndex = distr(gen);
                    bat.active = true;
                    bat.sprite.x = WIDTH;
                    bat.sprite.y = landHeights[bat.platformIndex] - spriteBat[0].img.getheight();
                }
            }

            if (bat.active) {
                bat.sprite.x -= BAT_SPEED;
                bat.animationIndex = (bat.animationIndex + 1) % 5;
                bat.sprite.img = spriteBat[bat.animationIndex].img;
                drawSprite(bat.sprite);

                if (bat.sprite.x < -bat.sprite.img.getwidth()) {
                    bat.active = false;
                    bat.spawnTimer = BAT_SPAWN_INTERVAL;
                }
            }
        }

        // Jump on space press
        if (_kbhit() && _getch() == ' ') {
            if (onLand) vy = -15;
        }

        timer.Sleep(60);  // Control frame rate
    }

    closegraph();
    return 0;
}
