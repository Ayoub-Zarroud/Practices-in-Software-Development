#include <SFML/Graphics.hpp>
#include <random>
#include <vector>

using namespace sf;

const int WIDTH = 800;
const int HEIGHT = 600;
const int NUM_LAND_BLOCKS = 7;
const int MAX_BATS = 2;                   // Maximum number of bats on screen
const float BAT_SPAWN_INTERVAL = 6.0f;    // Time interval between each bat spawn
const float BAT_SPEED = 4.0f;             // Speed at which bats move to the left

std::random_device rd;
std::mt19937 gen(rd());
std::uniform_int_distribution<> distr(0, NUM_LAND_BLOCKS - 1);

int dx_1 = 0, dx_2 = 0, vy = 0, g = 1, y; // Movement and physics variables
int heights[] = { 300, 340, 380, 420, 460, 500, 540 };
int landHeights[NUM_LAND_BLOCKS];

int main()
{
    RenderWindow window(VideoMode(WIDTH, HEIGHT), "Running Man Game");

    // Load fonts
    Font font;
    if (!font.loadFromFile("C:\\Windows\\Fonts\\Arial.ttf")) // Make sure to have the correct path to the font
        return -1;

    // Set up game-over text
    Text gameOverText;
    gameOverText.setFont(font);
    gameOverText.setString("Game Over! Press R to Restart");
    gameOverText.setCharacterSize(30);
    gameOverText.setFillColor(Color::Red);
    gameOverText.setPosition(WIDTH / 2 - 150, HEIGHT / 2 - 20);

    Texture textureBk, textureLand, textureJump, textureRun[8], textureBat[5];
    Sprite spriteBk, spriteLand, spriteJump, spriteRun[8], spriteBat[5];

    // Load textures
    for (int i = 0; i < 8; i++)
    {
        if (!textureRun[i].loadFromFile("runright" + std::to_string(i) + ".png"))
            return -1;
        spriteRun[i].setTexture(textureRun[i]);
    }

    for (int i = 0; i < 5; i++)
    {
        if (!textureBat[i].loadFromFile("bat" + std::to_string(i) + ".png"))
            return -1;
        spriteBat[i].setTexture(textureBat[i]);
    }

    if (!textureBk.loadFromFile("landscape1.png") ||
        !textureLand.loadFromFile("land.png") ||
        !textureJump.loadFromFile("jumpright.png"))
        return -1;

    spriteBk.setTexture(textureBk);
    spriteLand.setTexture(textureLand);
    spriteJump.setTexture(textureJump);

    for (int i = 0; i < NUM_LAND_BLOCKS; i++)
    {
        int randIndex = distr(gen);
        landHeights[i] = heights[randIndex];
    }

    int animationHandlerIndex = 0;
    y = heights[0] - spriteRun[0].getGlobalBounds().height;

    bool gameOver = false;

    struct Bat
    {
        Sprite sprite;
        int platformIndex;
        int animationIndex;
        bool active;
        float spawnTimer;
    };

    std::vector<Bat> bats(MAX_BATS);

    for (int i = 0; i < MAX_BATS; i++)
    {
        bats[i].sprite = spriteBat[0];
        bats[i].platformIndex = -1;
        bats[i].animationIndex = 0;
        bats[i].active = false;
        bats[i].spawnTimer = BAT_SPAWN_INTERVAL; // Initialize spawn timer
    }

    Clock clock;

    while (window.isOpen())
    {
        float deltaTime = clock.restart().asSeconds();

        Event event;
        while (window.pollEvent(event))
        {
            if (event.type == Event::Closed)
                window.close();

            if (gameOver && event.type == Event::KeyPressed && event.key.code == Keyboard::R)
            {
                gameOver = false;
                dx_1 = 0;
                dx_2 = 0;
                vy = 0;

                // Reset bats
                for (auto& bat : bats)
                {
                    bat.platformIndex = -1;
                    bat.active = false;
                    bat.spawnTimer = BAT_SPAWN_INTERVAL; // Reset spawn timer
                }

                // Set character's starting position on top of the first land block
                int playerPlatformIndex = 0; // Default platform index
                y = landHeights[playerPlatformIndex] - spriteRun[0].getGlobalBounds().height;
            }
        }

        window.clear();
        spriteBk.setPosition(dx_1, 0);
        window.draw(spriteBk);
        dx_1 -= 4;
        if (dx_1 <= -1200)
            dx_1 = 0;

        if (!gameOver)
        {
            for (int j = 0; j < NUM_LAND_BLOCKS; j++)
            {
                spriteLand.setPosition(j * 100 + dx_2, landHeights[j]);
                window.draw(spriteLand);
            }
            dx_2 -= 5;
            if (dx_2 <= -100)
            {
                dx_2 = 0;
                for (int j = 0; j < NUM_LAND_BLOCKS - 1; j++)
                {
                    landHeights[j] = landHeights[j + 1];
                }
                landHeights[NUM_LAND_BLOCKS - 1] = heights[distr(gen)];
            }

            vy += g;
            y += vy;

            if (y > HEIGHT)
            {
                gameOver = true;
                y = HEIGHT;
            }

            bool onLand = false;
            int playerPlatformIndex = -1; // Track which platform the player is on
            for (int j = 0; j < NUM_LAND_BLOCKS; j++)
            {
                FloatRect landBounds(j * 100 + dx_2, landHeights[j], spriteLand.getGlobalBounds().width, spriteLand.getGlobalBounds().height);
                FloatRect characterBounds(WIDTH / 4, y, spriteRun[0].getGlobalBounds().width, spriteRun[0].getGlobalBounds().height);

                if (landBounds.intersects(characterBounds))
                {
                    float overlap = std::min(characterBounds.left + characterBounds.width, landBounds.left + landBounds.width) - std::max(characterBounds.left, landBounds.left);

                    if (overlap >= characterBounds.width / 2)
                    {
                        onLand = true;
                        y = landHeights[j] - spriteRun[0].getGlobalBounds().height;
                        vy = 0;
                        playerPlatformIndex = j;
                        break;
                    }
                }
            }

            if (animationHandlerIndex > 7)
                animationHandlerIndex = 0;

            if (onLand && !gameOver)
            {
                spriteRun[animationHandlerIndex].setPosition(WIDTH / 4, y);
                window.draw(spriteRun[animationHandlerIndex]);
            }
            else if (!gameOver)
            {
                spriteJump.setPosition(WIDTH / 4, y);
                window.draw(spriteJump);
            }

            for (auto& bat : bats)
{
    if (!bat.active)
    {
        bat.spawnTimer -= deltaTime;
        if (bat.spawnTimer <= 0)
        {
            // Find a unique land block to spawn the bat above
            int randomIndex;
            bool validIndexFound = false;

            // Try to find a valid platform index that is not already occupied by another bat
            for (int attempt = 0; attempt < NUM_LAND_BLOCKS; ++attempt)
            {
                randomIndex = distr(gen);
                validIndexFound = true;

                // Check if the selected platform index is already occupied by another bat
                for (const auto& otherBat : bats)
                {
                    if (otherBat.active && otherBat.platformIndex == randomIndex)
                    {
                        validIndexFound = false;
                        break;
                    }
                }

                if (validIndexFound) break; // Exit the loop if a valid index is found
            }

            if (validIndexFound)
            {
                bat.platformIndex = randomIndex;
                bat.active = true;

                // Set bat position above the selected land block
                float batOffset = 10.0f; // Offset to position the bat above the land
                bat.sprite.setPosition(WIDTH, landHeights[bat.platformIndex] - bat.sprite.getGlobalBounds().height - batOffset);
            }
        }
    }

                if (bat.active)
                {
                    bat.sprite.move(-BAT_SPEED, 0);
                    bat.animationIndex = (bat.animationIndex + 1) % 5;
                    bat.sprite.setTexture(textureBat[bat.animationIndex]);
                    window.draw(bat.sprite);

                    // Improved collision box for accurate detection
                    FloatRect batBounds = bat.sprite.getGlobalBounds();
                    FloatRect batCollisionBox(
                        batBounds.left + batBounds.width * 0.1f,
                        batBounds.top + batBounds.height * 0.1f,
                        batBounds.width * 0.8f,
                        batBounds.height * 0.8f
                    );

                    FloatRect playerBounds(WIDTH / 4, y, spriteRun[0].getGlobalBounds().width, spriteRun[0].getGlobalBounds().height);

                    if (batCollisionBox.intersects(playerBounds))
                    {
                        gameOver = true;
                        break;
                    }

                    if (bat.sprite.getPosition().x < -bat.sprite.getGlobalBounds().width)
                    {
                        bat.active = false; // Deactivate bat once it goes off screen
                        bat.spawnTimer = BAT_SPAWN_INTERVAL; // Reset spawn timer for next bat
                    }
                }
            }
            animationHandlerIndex++;

            if (Keyboard::isKeyPressed(Keyboard::Space) && onLand && !gameOver)
            {
                vy = -23; // Higher jump velocity
            }
        }
        else
        {
            window.draw(gameOverText);
        }

        window.display();
        sleep(milliseconds(60));
    }

    return 0;
}
