import pgzrun  # 

WIDTH = 350   # 
HEIGHT = 600  # 

background = Actor('background')  # load background
bird = Actor('bird')  # load bird
bird.x = 50           # 
bird.y = HEIGHT/2     # 

def draw():   # iterative draw function
    background.draw()  # draw background
    bird.draw()        # draw bird

pgzrun.go()   # begin the game