#include <stdio.h>
#include <graphics.h>
#include <windows.h>
#include "conio.h"
#include "EasyXPng.h"

#pragma comment(lib, "Msimg32.lib") // Link with Msimg32.lib

#define WIDTH  640
#define HEIGHT 480
#define LEFT_IMAGE_COUNT 4  
#define RIGHT_IMAGE_COUNT 4  

// Define the putimagePNG function with a color key for transparency
void putimagePNG(int x, int y, IMAGE* img) {
    // Assuming black as the transparency color key (RGB(0, 0, 0))
    TransparentBlt(GetImageHDC(), x, y, img->getwidth(), img->getheight(),
        GetImageHDC(img), 0, 0, img->getwidth(), img->getheight(), RGB(0, 0, 0));
}

int main()
{
    IMAGE im_bk;
    IMAGE girl[8];

    initgraph(WIDTH, HEIGHT);

    for (int i = 0; i < 8; i++)
    {
        TCHAR filename[20];
        _stprintf_s(filename, _T("g%d.png"), i);
        loadimage(&girl[i], filename);  // Load PNG images with transparency
    }

    // Load background image
    loadimage(&im_bk, _T("bg0.png"));
    int x = 0; // Initial position of the girl
    int speed = 5; // Speed of the girl's movement
    int direction = 1; // 1 for right, -1 for left
    int currentImage = 0; // Index for current girl image

    BeginBatchDraw();
    while (1)
    {
        putimage(0, 0, &im_bk);  // Draw background

        // Draw the girl with transparency using our defined putimagePNG function
        if (direction == 1) {
            putimagePNG(x, HEIGHT - 175 - girl[currentImage + 4].getheight(), &girl[currentImage + 4]);
        }
        else {
            putimagePNG(x, HEIGHT - 175 - girl[currentImage].getheight(), &girl[currentImage]);
        }


        // Update position
        x += speed * direction;

        // Change direction when reaching the edges
        if (x + girl[currentImage + 4].getwidth() > WIDTH) {
            direction = -1;
            x = WIDTH - girl[currentImage + 4].getwidth();
        }
        else if (x < 0) {
            direction = 1;
            x = 0;
        }

        // Cycle through the images for the running effect
        currentImage = (currentImage + 1) % (direction == 1 ? RIGHT_IMAGE_COUNT : LEFT_IMAGE_COUNT);

        FlushBatchDraw();
        Sleep(30);

        // Exit condition
        if (_kbhit() && _getch() == 27)
            break;
    }

    closegraph();
    return 0;
}
