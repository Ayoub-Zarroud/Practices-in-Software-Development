import pgzrun   
import random   
import time

WIDTH = 480     
HEIGHT = 700    
TITLE = 'Python Aircraft'
score = 0      
isLoose = False  
isStart = False

sounds. game_music.play(-1)  

start_yes = Actor('start_no')
start_yes.x = WIDTH/2
start_yes.y = HEIGHT/2


background1 = Actor('background')   
background1.x = 480/2   
background1.y = 852/2   
background2 = Actor('background')   
background2.x = 480/2    
background2.y = -852/2   

bullet = Actor('bullet')   
bullet.x = WIDTH/2         
bullet.y = -HEIGHT   

bullet2 = Actor('bullet')   
bullet2.x = WIDTH/2         
bullet2.y = -HEIGHT  

hero = Actor('hero')   
hero.x = WIDTH/2       
hero.y = HEIGHT*2/3    

enemy = Actor('enemy')   
enemy.x = WIDTH/2        
enemy.y = 0              

def draw():  
    global isStart
    if not isStart:
        background1.draw()   
        background2.draw() 
        start_yes.draw()  
        return
    screen.clear()
    background1.draw()   
    background2.draw()
    hero.draw()  
    enemy.draw()   
    bullet.draw()  
    bullet2.draw() 
    screen.draw.text("score: "+str(score), (200, HEIGHT-50), fontsize=30,fontname='s', color='black')
    if isLoose:   
        screen.draw.text("Fail!", (50, HEIGHT/2), 
        fontsize=90,fontname='s', color='red')

def update():   
    global score, isLoose, isStart

    if not isStart:
        return

    if isLoose:
        return  

    if background1.y > 852/2 + 852:
        background1.y = -852/2   
    if background2.y > 852/2 + 852:
        background2.y = -852/2   
    background1.y += 1   
    background2.y += 1   

    if bullet.y > -HEIGHT:
        bullet.y = bullet.y - 10  

    if bullet2.y > -HEIGHT:
        bullet2.y = bullet2.y - 5

    enemy.y += 3  
    if enemy.y > HEIGHT:  
        enemy.y = 0 
        enemy.x = random.randint(50, WIDTH-50)   

    bullet1_used = bullet.colliderect(enemy)
    bullet2_used = bullet2.colliderect(enemy)

    if bullet1_used or bullet2_used:  
        sounds.got_enemy.play()   
        enemy.y = 0   
        enemy.x = random.randint(0, WIDTH)   
        score = score + 1  
        if bullet1_used:
            bullet.y = -HEIGHT
        if bullet2_used:
            bullet2.y = -HEIGHT 

    if hero.colliderect(enemy):  
        sounds.explode.play()   
        isLoose = True   
        hero.image = 'hero_blowup'  

def on_mouse_move(pos, rel, buttons):  
    global isStart, start_yes
    if not isStart:
        mouse_x, mouse_y = pos
        inBound_x = True if mouse_x >= WIDTH/2-100 and mouse_x <= WIDTH/2+100 else False
        inbound_y = True if mouse_y >= HEIGHT/2-42 and mouse_y <= HEIGHT/2+42 else False
        if inBound_x and inbound_y:
            start_yes.image = 'start_yes' 
        else :
            start_yes.image = 'start_no'
    if isLoose:
        return   
    hero.x = pos[0]   
    hero.y = pos[1]   

def on_mouse_down(pos):  
    global isStart, start_yes
    if not isStart:
        mouse_x, mouse_y = pos
        inBound_x = True if mouse_x >= WIDTH/2-100 and mouse_x <= WIDTH/2+100 else False
        inbound_y = True if mouse_y >= HEIGHT/2-42 and mouse_y <= HEIGHT/2+42 else False
        if inBound_x and inbound_y:
            isStart = True
    if isLoose:
        return  
    sounds.gun.play() 
    bullet.x = hero.x    
    bullet.y = hero.y - 70
    bullet2.x = hero.x    
    bullet2.y = hero.y - 30



pgzrun.go()   
